import { Box } from "@mui/system";
import Typography from '@mui/material/Typography';

function NotFound() {
    return (
        <div className="App-header">
            <Box >
                <img src="" />
                < Box>
                    <Typography variant="h1">404 Not Found</Typography>
                </Box>
            </Box>
        </div>
    );
};

export default NotFound;