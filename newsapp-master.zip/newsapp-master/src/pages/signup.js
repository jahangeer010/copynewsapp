import { Box } from "@mui/system";
import Typography from '@mui/material/Typography';

function SignupUser(){
    return (
        <Box>
            < Box>
            <Typography variant="h3">SignUp</Typography>
            </Box>
        </Box>
    );
};

export default SignupUser;