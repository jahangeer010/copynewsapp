import { Box } from "@mui/system";
import Typography from '@mui/material/Typography';

function Articles (){
    return (
        <Box>
            <Typography>Articles</Typography>
        </Box>
    );
};

export default Articles;