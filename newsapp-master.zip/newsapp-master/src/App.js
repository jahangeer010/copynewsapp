import './App.css';
import AppRouter from './config/router/routering';

function App() {
  return (
    <div className="App">
      <AppRouter />      
    </div>
  );
}

export default App;
